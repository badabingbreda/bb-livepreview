# bb-livepreview
By the press of a button view your layout as if you were on the frontend, not on the backend.
Also adds a quicksave button, which publishes the layout with just one click.

Installation:
Unzip the archive and put the bb-livepreview folder into your plugins folder (/wp-content/plugins/).
Activate the plugin from the Plugins menu.

Two buttons will show at the left of the screen whenever you are in the Beaver Builder Editor. Top is preview-toggle, lower is Quicksave.
